package com.lex.demo;

import android.annotation.SuppressLint;
import android.content.Context;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.view.Menu;
import android.view.MenuItem;
import android.webkit.JavascriptInterface;
import android.webkit.WebView;
import android.widget.TextView;

@SuppressLint("SetJavaScriptEnabled")
public class MainActivity extends AppCompatActivity {

    private WebView mWebView;
    private TextView mTextView;

    @SuppressLint("JavascriptInterface")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        mWebView = (WebView) findViewById(R.id.web_view);
        mTextView = (TextView) findViewById(R.id.text);
        mWebView.getSettings().setDefaultTextEncodingName("utf-8");
        mWebView.getSettings().setJavaScriptEnabled(true);
        mWebView.addJavascriptInterface(new JavaScriptInterface(this), "androidJs");
        mWebView.loadUrl("file:///android_asset/web.html");
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.native_call_js) {
            mWebView.loadUrl("javascript:androidCallJs('Text From Android')");
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    public class JavaScriptInterface {

        Context context;

        JavaScriptInterface(Context context) {
            this.context = context;
        }

        // Js中通过约定的androidJs句柄，调用jsCallAndroid方法
        @JavascriptInterface
        public Boolean jsCallAndroid(final String name) {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    mTextView.setText(name);
                }
            });
            return true;
        }
    }

}
